<template>
  <div class="">角色列表</div>
</template>

<script setup>
import {} from 'vue'
</script>

<style lang="scss" scoped></style>
